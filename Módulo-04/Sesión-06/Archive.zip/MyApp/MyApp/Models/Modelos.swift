//
//  Modelos.swift
//  MyApp
//
//  Created by Jan Zelaznog on 11/10/21.
//

import Foundation

struct Account {
    let user: String
    let pass: String
}

struct Registered {
  let user1: Account = Account(user: "ricardo@bedu.org", pass: "Password10")
}

struct Track: Codable, Hashable {
    let title: String?
    let artist: String?
    let album: String?
    let song_id: String?
    let genre: String?
    //let duration: String?
    
    enum CodingKeys: String, CodingKey {
        case artist
        case title = "name"
        case album
        //case duration
        case genre
        case song_id = "song_id"
    }
}

enum PlayerStates {
    case play
    case pause
    case next
    case previous
}


var misTracks = [Track]() 
