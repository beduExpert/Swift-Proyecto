//
//  Protocols.swift
//  MyApp
//
//  Created by Jan Zelaznog on 13/10/21.
//

import UIKit
import Foundation

protocol ButtonOnCellDelegate {
    func buttonTouchedOnCell(aCell:UITableViewCell)
}

