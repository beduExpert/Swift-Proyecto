//
//  MainViewController.swift
//  MyApp
//
//  Created by Jan Zelaznog on 10/10/21.
//

import UIKit

class MainViewController: UIViewController {

    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var imagen: UIImageView!
    @IBAction func logout(_ sender: Any) {
        dismiss(animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        imagen.image = UIImage(systemName: "person.fill")
        
        let gesture = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        self.imagen.addGestureRecognizer(gesture)
        self.imagen.isUserInteractionEnabled = true

    }
    
    @objc func handleTap(sender: UITapGestureRecognizer) {
        SetInfo()
    }
    
    func SetInfo() {
        let appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
        let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String
        let appName = Bundle.main.infoDictionary?["CFBundleName"] as? String
        
        let info = """
            Copyright © 2021
            \(appName ?? "")
            Version \(appVersion ?? "") (\(build ?? ""))
            """
        
        self.showSimpleAlert(info)
    }
    
    @IBAction func handlePinch(_ sender: UIPinchGestureRecognizer) {
        guard let _ = sender.view else {
                    return
                }
                
                if let scale = (sender.view?.transform.scaledBy(x: sender.scale, y: sender.scale)) {
                    guard scale.a > 1.0 else { return }
                    guard scale.d > 1.0 else { return }
                    
                    sender.view?.transform = scale
                    sender.scale = 1.0
                 }

    }
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
