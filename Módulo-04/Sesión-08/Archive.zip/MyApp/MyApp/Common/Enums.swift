//
//  Enums.swift
//  MyApp
//
//  Created by Ivan Alejandro Hernandez Sanchez on 27/11/21.
//

import Foundation

enum MenuOption: Int {
    case deleteFromLibrary = 0
    case download
    case addToPlaylist
    
    
}
