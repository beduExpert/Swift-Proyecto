//
//  TracksTableViewController.swift
//  MyApp
//
//  Created by Jan Zelaznog on 13/10/21.
//

import UIKit

import CoreData

class TracksTableViewController: UITableViewController, ButtonOnCellDelegate {
    
    
    func buttonTouchedOnCell(aCell: UITableViewCell) {
        print ("touch")
        let apvc = AudioPlayerViewController()
        self.present(apvc, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.backgroundColor = .black
        self.tableView.register(TrackTableViewCell.self, forCellReuseIdentifier: "reuseIdentifier")
        self.tableView.rowHeight = 80;
        
        //DownloadManager.shared.startDownload(url: URL(string: "https://speed.hetzner.de/100MB.bin")!)
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.managedObjectContext
         
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "TrackList")
        //Leemos la info en COREDATA
        request.returnsObjectsAsFaults = false
        do {
            let result = try context!.fetch(request)
            misTracks = [Track]()
            for data in result as! [NSManagedObject] {
                let title = data.value(forKey: "title") as? String
                let artist = data.value(forKey: "artist") as? String
                let album = data.value(forKey: "album") as? String
                let song_id = data.value(forKey: "song_id") as? String
                let gender = data.value(forKey: "gender") as? String

                let track = Track(title: title ?? "", artist: artist ?? "", album: album ?? "", song_id: song_id ?? "", genre: gender ?? "")
                misTracks.append(track)
                print(data.value(forKey: "title") as! String)
                        
            }
            self.tableView.reloadData()
        } catch {
                    
            print("Failed")
        }
        
        
        
        
        
        if true { //TODO: Quitamos esta linea solo si queremos buscar la info desde servicio
        RestServiceManager.shared.getToServer(responseType: [Track].self, method: .get, endpoint: "songs") { status, data in
            misTracks = [Track]()
            if let _data = data {
                misTracks = _data
                
                if let _context = context {
                    let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "TrackList")
                    let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)

                    do {
                        try appDelegate.persistentStoreCoordinator?.execute(deleteRequest, with: _context)
                    } catch let error as NSError {
                        // TODO: handle the error
                        print(error)
                    }
                    
                    //Guardamos la info en COREDATA
                    for item in _data {
                        guard let trackEntity = NSEntityDescription.insertNewObject(forEntityName: "TrackList", into: _context) as? NSManagedObject else {
                            return
                        }
                        
                        trackEntity.setValue(item.artist, forKey: "artist")
                        trackEntity.setValue(item.title, forKey: "title")
                        trackEntity.setValue(item.song_id, forKey: "song_id")
                        trackEntity.setValue(item.album, forKey: "album")
                        trackEntity.setValue(item.genre, forKey: "gender")

                        do {
                            try _context.save()
                        } catch {
                            print("Could not save. \(error), \(error.localizedDescription)")
                        }
                    }
                
                }
                
                self.tableView.reloadData()
            }
        }
        }
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(updateTable(_:)),
                                               name: NSNotification.Name("updateTable"),
                                               object: nil)
        
        let _ = Timer.scheduledTimer(withTimeInterval: 30.0, repeats: true) { timer in
            NotificationCenter.default.post(name: NSNotification.Name("updateTable"), object: nil)
        }
    }
    
    @objc func updateTable(_ notification: Notification) {
        
        misTracks.append(Track(title: "Nueva cancion", artist: "Nuevo artista", album: "Nuevo album", song_id: "0", genre: "Genero")) //, duration: "123"))
        tableView.reloadData()
    }

    // MARK: - Table view data source
    

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return misTracks.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath) as! TrackTableViewCell
        let track = misTracks[indexPath.row]
        cell.backgroundColor = .clear
        
        cell.track = track
        cell.parent = self
                
        cell.setValues()
        return cell
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
